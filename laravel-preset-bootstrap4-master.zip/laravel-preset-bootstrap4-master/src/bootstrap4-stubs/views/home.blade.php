@extends('layouts.app')

@section('content')

    <div class="jumbotron">
        <div class="container p-5">
            <h1 class="display-1">Dashboard</h1>

            <p class="lead ml-2 text-success">
                You are logged in!
            </p>
        </div>
    </div>

@endsection
